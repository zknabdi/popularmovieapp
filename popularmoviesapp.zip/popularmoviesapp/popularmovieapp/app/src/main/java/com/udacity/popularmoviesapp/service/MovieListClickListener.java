package com.udacity.popularmoviesapp.service;

import com.udacity.popularmoviesapp.model.Movie;

public interface MovieListClickListener {
    void onMovieListClick(Movie movie);
    //void onMovieListClick(int moviePos);

}
